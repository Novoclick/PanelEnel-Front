export const environment = {
  production: true,
  development: 'https://panel-node.herokuapp.com'
  // development: 'http://localhost:3000'
};
